<div class = 'footer'>
  <ul class = 'footnotes'>
  	<li><a href = '#'>Home</a></li>
  	<li>|</li>
  	<li><a href = '#'>Products</a></li>
  	<li>|</li>
  	<li><a href = '#'>Forum</a></li>
  	<li>|</li>
  	<li><a href = '#'>Blog</a></li>
  	<li>|</li>
  	<li><a href = '#'>About Us</a></li>
   </ul>	
</div>
</div>
<script type="text/javascript" src ="http://localhost/Equiplex_Metro/assets/js/metrojs.js"></script>
	<script type="text/javascript">
	   $(".live-tile").liveTile();
	</script>
</body>
</html>

