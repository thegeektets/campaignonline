<html>
<head>
	  <title><?php echo $title.":".$portfolio[0]["product_name"] ?>|Equiplex Business Solutions</title>
	<style type="text/css">
	 .navbar{
	   background: #001A56;
	   color: white;
	}
	.footnotes{
		list-style: none;
	    margin-left: 30%;	
	}
	.footer{
	 background: #000;
	}
	a{
		text-decoration: none;
	}
	table.metro{
		margin-left: 10%;
	}
	.footnotes li{
	 float: left;
	 padding-left: 20px;

	}
	.sc{
		box-shadow:0 0 10px;
		min-height:140px;
	}
	body {
  color: #333;
  background-color: #FFF;
  background :url("/Equiplex_Metro/assets/img/mainbg.jpeg");
}
.main {
	display: block;
	padding: 4px;
	margin-top: 0px;
	margin: auto;
	width: 80%;
	line-height: 20px;
	border: 2px solid #ddd;

	-webkit-border-radius: 25px;
	-moz-border-radius: 25px;
	border-radius: 25px;
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	-webkit-box-shadow: none;
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	-moz-box-shadow: none;
	box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	box-shadow: none;
	-webkit-transition: all 0.2s ease-in-out;
	-moz-transition: all 0.2s ease-in-out;
	-o-transition: all 0.2s ease-in-out;
	transition: all 0.2s ease-in-out;
}
.metro{
	margin: auto;
    display: block;
    
	width: 100%;
    background: #001A56;
	
}
.table .td{
width: 25px;
height: 25px;

}



	</style>
	
	<link rel="stylesheet" type="text/css" href="/Equiplex_Metro/assets/css/bootmetro.css">
	<link rel="stylesheet" type="text/css" href="/Equiplex_Metro/assets/css/bootmetro-responsive.css">
	<link rel="stylesheet" type="text/css" href="/Equiplex_Metro/assets/css/bootmetro-ui-light.css">
	<link rel="stylesheet" type="text/css" href="/Equiplex_Metro/assets/css/metrojs.css">
	<link rel="stylesheet" type="text/css" href="/Equiplex_Metro/assets/css/bootmetro-icons.css">

	<link href="/Equiplex_Metro/assets/css/css.css" rel="stylesheet" type="text/css">
		
	<link rel="stylesheet" href="/Equiplex_Metro/assets/css/normalize.css">
	<link rel="stylesheet" href="/Equiplex_Metro/assets/css/main.css">

		<script src="/Equiplex_Metro/assets/css/ga.js" async="" type="text/javascript"></script><script type="text/javascript">

		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-36665770-1']);
		  _gaq.push(['_trackPageview']);

		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();

		</script>

	<script type="text/javascript" src ="/Equiplex_Metro/assets/js/jquery-1.10.0.min.js"></script>
    <script type="text/javascript" src ="/Equiplex_Metro/assets/js/jscript.js"></script>

		<script src="/Equiplex_Metro/assets/js/jquery_002.js"></script>
		<script>window.jQuery || document.write('<script src="/Equiplex_Metro/assets/jsjs/vendor/jquery-1.8.3.min.js"><\/script>')</script>

		<script src="/Equiplex_Metro/assets/js/jquery.js"></script>
		<script src="/Equiplex_Metro/assets/js/jQuery.js"></script>
		<script src="/Equiplex_Metro/assets/js/main.js"></script>
   
</head>
<body>
	<div class = 'container-fluid'>
		<div class = 'navbar'>
			<div class = 'navbar-inner'>
				<a href="#" class =  'brand'>Equiplex Business Solutions <br/><br/> <small> your software experts</small></a> 
			
					<ul class = 'nav pull-right'>
					<li>
						<a href="/Equiplex_Metro/index.php/home" class = 'win-command' rel ='tootip' title ='Home'>
  							<span class = 'win-commandicon win-commandring icon-home'></span>
  							<span class = 'win-label'>Home</span>
  						</a>
					</li>
					<li>
						<a href="/Equiplex_Metro/index.php/products" class = 'win-command' rel ='tootip' title ='Products'>
  							<span class = 'win-commandicon win-commandring icon-bag'></span>
  							<span class = 'win-label'>Products</span>
  						</a>
					</li>
					
					<li>
						<a href="" class = 'win-command' rel ='tootip' title ='Forum'>
  							<span class = 'win-commandicon win-commandring icon-bubbles-2'></span>
  							<span class = 'win-label'>Forum</span>
  						</a>
					</li>
					<li>
						<a href="" class = 'win-command' rel ='tootip' title ='About'>
  							<span class = 'win-commandicon win-commandring icon-info-2'></span>
  							<span class = 'win-label'>About Us</span>
  						</a>
					</li>
					<li>
						<a href="" class = 'win-command' rel ='tootip' title ='Users'>
  							<span class = 'win-commandicon win-commandring icon-users-3'></span>
  							<span class = 'win-label'>Users</span>
  						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>

	  

	<body>
		<div id="wrap">
			<div style="display: none;" id="loader"><i></i></div>

				<div class="gray_section js-gray_section" id="gray_section"><i class="sh" id="gray_section_sh"></i>
<div class ='span4'>
<a href="products/reviewproduct">
					<img alt="300x200" data-src="holder.js/300x200" style="width: 300px; height: 200px;" src="<?php echo $portfolio[0]["product_pic"] ;?>">
				</a>
  <p>
<a href="#"><h3 ><?php echo $portfolio[0]["product_name"] ;?></h3></a>
<h3 style ="color:#fff;">Description :</h3><p style ="color:#fff;"><?php echo $portfolio[0]["product_desc"] ;?></p>

<h3 style ="color:#fff;">Tools :</h3>
<ul style ="color:#fff;">
	<?php
 $i=0;
 While($i < count($tools)){


 echo "<li>".$tools[$i]["tool"] ."</li>";
 $i++;

}
 ?>
</ul>
<h3 style ="color:#fff;">Other Projects done by <?php echo $portfolio[0]["full_names"] ;?> :</h3>
	<ul style ="color:#fff;"> 

	<?php
 $i=0;
 While($i < count($others)){
?>
 <li>
 	<a href="/Equiplex_Metro/index.php/products">
 	<?php echo $others[$i]['product_name'] ?>
    </a>
</li>
<?php
 $i++;

}
 ?>
</ul>
</div>
				<div class="slogan js-slogan" id="slogan_section" style ='float:left;'>
				<div class="limit">
		               	
			   
							<p class="left">
								PROJECT <strong style="color:#00AD68">NAME:<?php echo $portfolio[0]["product_name"]?></strong>
							</p>
							<p class="left">
								PROJECT <strong style="color:#00AD68">DEVELOPER:<?php echo $portfolio[0]["full_names"]?></strong>
							</p>
							
    					</div>
    				</div>
				</div>
		
<div class = 'main' id="main">

	<div class = 'row' style='margin:auto;'>

		<div class = 'span4'>
        <h3>DEVELOPER DETAILS</h3>
            <hr/>
					<img alt="200*180" data-src="holder.js/200x180" style="width: 200px; height: 180px;" 
					src="<?php echo $developer[0]["avatar"] ;?>">
				<table>
				<tr><td>Username :</td><td><?php echo $developer[0]["username"] ;?></td></tr>
				<tr><td>Fullname :</td><td><?php echo $developer[0]["full_names"] ;?></td></tr>
				<tr><td>Country :</td><td><?php echo $developer[0]["country"] ;?></td></tr>
                <tr><td>Company :</td><td><?php echo $developer[0]["company"] ;?></td></tr>


					</table>

		</div>

		<div class = 'span4'>
					<h3>DOWNLOAD</h3>	
			<hr/>
<a class="btn large btn-success" href="#" style="width:80%; height:50%; margin:auto;position:center;">Download</a>

          

		</div>
		<div class = 'span4'>
		<h3>POST REVIEW MESSAGE</h3>	
			<hr/>
			<form>
		    <label>Username</label>
			     <div class="input-control text"> <input type="text" name="username" /><button class="btn-clear"></button> </div> <label>Message</label>
		     <div class="input-control textarea">
              <textarea name="message" height = "40%"></textarea>
             </div>  
     <input class='btn large btn-success' type="submit" value="POST"/>




			</form>

		</div>

	</div>

</div>





	

</body></html>