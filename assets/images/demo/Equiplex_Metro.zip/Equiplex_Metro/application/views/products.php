<html>
<div class="main">
<ul class="listview fluid  thumbnails">

  <?php
 $i=0;
 While($i < count($portfolio)){
 // var_dump($portfoliopics);
  ?>
<li class="span4">
<div class="thumbnail">
  <a href="products/reviewproduct">
<img alt="300x200" data-src="holder.js/300x200" style="width: 300px; height: 200px;" src="<?php echo $portfolio[$i]["product_pic"] ;?>">
</a>
<div class="caption">
  <p>
<a href="products/reviewproduct/<?php echo $portfolio[$i]["product_id"] ;?>"><h5><?php echo $portfolio[$i]["product_name"] ;?></h5></a>
Product Developer :<a href="#"><?php echo $portfolio[$i]["full_names"] ;?></a><br/>
Date Uploaded :<p><?php echo $portfolio[$i]["date_time"] ;?></p> <br/>

<a class="btn btn-primary" href="products/reviewproduct/<?php echo $portfolio[$i]["product_id"]?>">Review</a>
<a class="btn btn-success" href="products/reviewproduct/<?php echo $portfolio[$i]["product_id"]?>">Download</a>
</p>
</div>
</div>
</li>

  <?php
$i++;
  }
?>
</ul>
</div>
</div>


</div>
    

 </body>
</html>