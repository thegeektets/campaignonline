
<html>
<?php
    $this->load->helper('url');
    ?>
<head>
	  <title><?php echo $title ?> | Equiplex Business Solutions</title>
	<style type="text/css">
	 .navbar{
	   background: #001A56;
	   color: white;
	}
	.footnotes{
		list-style: none;
	    margin-left: 30%;	
	}
	.footer{
	 background: green;
	}
	a{
		text-decoration: none;
	}
	table.bname{
		z-index: 0;
		margin-left: 20%;
		
	}
	table.tag{
		display: none;
		margin-left: 20%;
		position: fixed;
	}
	
	.subcontent{
		margin-left: 10%;
	}
	.footnotes li{
	 float: left;
	 padding-left: 20px;

	}
	</style>
	<link rel="icon" type="image/png" href="<?php echo base_url("/assets/img/equiplexfav.ico")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootmetro.css")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/customanimations.css")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/animate.min.css")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/metrojs.css")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootmetro-icons.css")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootmetro-responsive.css")?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootmetro-ui-light.css")?>">
	<script type="text/javascript" src ="<?php echo base_url("/assets/js/jquery-1.10.0.min.js")?>"></script>
    <script type="text/javascript" src ="<?php echo base_url("/assets/js/jscript.js")?>"></script>
</head>
<body>
	<div class = 'container-fluid'>
		<div class = 'navbar'>
			<div class = 'navbar-inner' >
				<a href="#" class =  'brand'>Equiplex Business Solutions <br/>
				<img src = '<?php echo base_url("/assets/img/Elogo.png")?>' height = '100' width = '100'><br/>
				<small> Your Software Experts</small></a> 
			
					<ul class = 'nav pull-right'>
					<li>
						<a href="<?php echo base_url("/index.php/home")?>" class = 'win-command' rel ='tootip' title ='Home'>
  							<span class = 'win-commandicon win-commandring icon-home'></span>
  							<span class = 'win-label'>Home</span>
  						</a>
					</li>
					<li>
						<a href="<?php echo base_url("/index.php/home")?>" class = 'win-command' rel ='tootip' title ='Products'>
  							<span class = 'win-commandicon win-commandring icon-bag'></span>
  							<span class = 'win-label'>Products</span>
  						</a>
					</li>
					
					<li>
						<a href="" class = 'win-command' rel ='tootip' title ='Forum'>
  							<span class = 'win-commandicon win-commandring icon-bubbles-2'></span>
  							<span class = 'win-label'>Forum</span>
  						</a>
					</li>
					<li>
						<a href="" class = 'win-command' rel ='tootip' title ='About'>
  							<span class = 'win-commandicon win-commandring icon-info-2'></span>
  							<span class = 'win-label'>About Us</span>
  						</a>
					</li>
					<li>
						<a href="" class = 'win-command' rel ='tootip' title ='Users'>
  							<span class = 'win-commandicon win-commandring icon-users-3'></span>
  							<span class = 'win-label'>Users</span>
  						</a>
					</li>
				</ul>
			</div>
		</div>
</div>
	


	  <title><?php echo $title ?>|Equiplex Business Solutions</title>
	<style type="text/css">
	body {
  color: #333;
  background-color: #FFF;
  background :url("/Equiplex_Metro/assets/img/mainbg.jpeg");
}
.main {
	display: block;
	padding: 4px;
	margin: auto;
	width: 80%;
	line-height: 20px;
	border: 2px solid #ddd;

	-webkit-border-radius: 25px;
	-moz-border-radius: 25px;
	border-radius: 25px;
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	-webkit-box-shadow: none;
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	-moz-box-shadow: none;
	box-shadow: 0 1px 3px rgba(0, 0, 0, 0.055);
	box-shadow: none;
	-webkit-transition: all 0.2s ease-in-out;
	-moz-transition: all 0.2s ease-in-out;
	-o-transition: all 0.2s ease-in-out;
	transition: all 0.2s ease-in-out;
}



	</style>
